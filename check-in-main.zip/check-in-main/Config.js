// ประกาศค่า URL ที่ใช้เชื่อมต่อกับ Web App
    const WEB_APP_MEMBER_URL = 'https://script.google.com/macros/s/AKfycbwR5z1QhMd3588Hn5pW7kF55p0pUp4AG2ZmbzVDHTOhNBOFjjPuWdKIny8G8_rT0rodmA/exec';
    const WEB_APP_URL = 'https://script.google.com/macros/s/AKfycbxu9h0ZJLm0h__BEahkGehV5nahKBs-aED6V4hYQnw-XxBmoUEuxIyZ4YHr_CRXEm53/exec';
//LIFF_ID
    const LIFF_ID = '2007747842-OGeyrGkv'; // LIFF ID Checkin
    const LIFF_HISTORY = '2007747842-p0YX1oBn'; // LIFF ID history
    const LIFF_REGISTER = '2007747842-oJr1GXK2'; // LIFF ID register
